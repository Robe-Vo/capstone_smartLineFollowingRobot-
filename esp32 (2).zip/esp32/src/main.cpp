#include <Arduino.h>
#include "app/app.hpp"

void setup() {
  App_setup();
}

void loop() {
  App_loop();
}
