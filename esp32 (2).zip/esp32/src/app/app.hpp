#pragma once
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

void App_setup();
void App_loop();

#ifdef __cplusplus
}
#endif
