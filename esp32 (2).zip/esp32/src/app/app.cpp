#include "app.hpp"

#include <Arduino.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

#include <math.h>


#include "bluetooth.hpp"
#include "sensors.hpp"
#include "actuators.hpp"

#include "cfg.hpp"
#include "pin.hpp"

#include "state/state.hpp"
#include "protocol/protocol.hpp"
#include "control/control.hpp"
#include "telemetry/telemetry.hpp"

// ======================= GLOBALS =======================


static Network g_net;

// RTOS task handles
static TaskHandle_t gTaskComm  = nullptr;
static TaskHandle_t gTaskPID   = nullptr;
static TaskHandle_t gTaskUltra = nullptr;

// 1 ms tick timer
static hw_timer_t* gTimer1ms = nullptr;
static volatile uint32_t gTickMs = 0;

// PID state (tùy chọn, có thể chưa dùng)
static Control::SpeedCtrlState gPid;
static Control::ValueBuffer    gPidDbg;

// Ultra period (ms), mặc định từ cfg
static volatile uint16_t gUltraPeriodMs = ULTRA_TRIG_PERIOD_MS_DEFAULT;


enum class OpDriveMode : uint8_t {
    PWM_OPEN_LOOP     = 0,
    SPEED_CLOSED_LOOP = 1
};

struct OperationSetpoint {
    OpDriveMode mode      = OpDriveMode::PWM_OPEN_LOOP;
    bool        enabled   = false;

    uint16_t    pwm_cmd   = 0;       // open-loop duty 0..SPEED_MAX_INPUT
    float       speed_ref = 0.0f;    // closed-loop ref [Hz], >0 FWD, <0 BWD

    uint16_t    steer_deg = SERVO_MID_DEG;
};

static OperationSetpoint gOpSp;


// Param buffers (giữ raw 30 byte cho mỗi nhóm)
static uint8_t gLineParams[30];
static uint8_t gMpuParams[30];
static uint8_t gUltraParams[30];
static uint8_t gMotorParams[30];
static uint8_t gServoParams[30];
static uint8_t gPidParams[30];

// ======================= FORWARD DECLS =======================

static void Task_Comm(void* arg);
static void Task_PID(void* arg);
static void Task_Ultra(void* arg);

static void handleSystemCmd(const Protocol::RxFrame& f);
static void handleIdleCmd(const Protocol::RxFrame& f);
static void handleOperationCmd(const Protocol::RxFrame& f);

// 1 ms timer ISR
void IRAM_ATTR onTimer1ms()
{
  BaseType_t xHigherPriorityTaskWoken = pdFALSE;

  gTickMs++;
  uint32_t t = gTickMs;

  // COMM: luôn chạy, kể cả khi IDLE (để nhận lệnh + gửi ACK)
  if ((t % TS_COMMUNICATION_MS) == 0 && gTaskComm) {
    vTaskNotifyGiveFromISR(gTaskComm, &xHigherPriorityTaskWoken);
  }

  // Chỉ có PID + ULTRA phụ thuộc mode OPERATION
  if (State::isOperation()) {
    // PID: lệch pha 5 ms
    const uint32_t PID_OFFSET_MS = 5;
    if (t >= PID_OFFSET_MS &&
        ((t - PID_OFFSET_MS) % TS_CONTROLLER_MS) == 0 &&
        gTaskPID) {
      vTaskNotifyGiveFromISR(gTaskPID, &xHigherPriorityTaskWoken);
    }

    // ULTRA TRIG: dùng period runtime (gUltraPeriodMs)
    uint16_t up = gUltraPeriodMs;
    if (up > 0 && (t % up) == 0 && gTaskUltra) {
      vTaskNotifyGiveFromISR(gTaskUltra, &xHigherPriorityTaskWoken);
    }
  }

  // Reset tick để tránh tràn
  if (t >= TS_RESET_TMR) {
    gTickMs = 0;
  }

  if (xHigherPriorityTaskWoken == pdTRUE) {
    portYIELD_FROM_ISR();
  }
}


// ======================= SETUP / LOOP =======================

void App_setup()
{
  Serial.begin(115200);

  // Network
  g_net.begin();

  // Sensors
  line_setup(LINE_SENSOR_IDX_1_PIN, LINE_SENSOR_IDX_2_PIN, LINE_SENSOR_IDX_3_PIN,
             LINE_SENSOR_IDX_4_PIN, LINE_SENSOR_IDX_5_PIN);

  ultra_setup(ULTRASONIC_TRIG_PIN, ULTRASONIC_ECHO_PIN);
  attachInterrupt(ULTRASONIC_ECHO_PIN, hanlder_ultra_echo, CHANGE);

  // Encoder + motor
  MotorPWM11::begin(MOTOR_PWM_PIN, MOTOR_OUT_1_PIN, MOTOR_OUT_2_PIN,
                    PWM_CH_MOTOR, PWM_FREQ_HZ);
  MotorPWM11::setDeadband(MOTOR_DEADBAND_DUTY_DEFAULT);


  // init encoder module (sets PIN_A/PIN_B used by ISR + attach interrupts)
  Encoder::speed_filter_init();
  Encoder::HybridConfig hc;  // dùng default từ cfg.hpp
  Encoder::encoder_begin(ENCODER_CHANNEL_A_PIN, ENCODER_CHANNEL_B_PIN,
                        ENC_EFFECTIVE_PPR, hc);

  // State
  State::setMode(State::Mode::IDLE);
  gOpSp = OperationSetpoint(); // 0, mid, false
    // hoặc đơn giản chỉ cần reset về mặc định:
    // gOpSp = OperationSetpoint();

  // PID (tham số lấy từ cfg.hpp)
  Control::PID_setupFromCfg(gPid);

  // RTOS tasks
  // Core 0: COMM (prio 3), PID (prio 4)
  xTaskCreatePinnedToCore(Task_Comm,  "comm",  4096, nullptr, 3, &gTaskComm, 0);
  xTaskCreatePinnedToCore(Task_PID,   "pid",   4096, nullptr, 4, &gTaskPID,  0);

  // Core 1: Ultra (prio 1, thấp nhất)
  xTaskCreatePinnedToCore(Task_Ultra, "ultra", 2048, nullptr, 1, &gTaskUltra,1);

  // 1 ms hardware timer
  gTimer1ms = timerBegin(0, 80, true);     // 80 MHz / 80 = 1 MHz
  timerAttachInterrupt(gTimer1ms, &onTimer1ms, true);
  timerAlarmWrite(gTimer1ms, 1000, true);  // 1000 tick @1MHz = 1 ms
  timerAlarmEnable(gTimer1ms);
}

void App_loop()
{
  // Không làm gì, mọi thứ chạy trên RTOS task + timer
  vTaskDelay(pdMS_TO_TICKS(100));
}

// ======================= TASK: COMM =======================

static void Task_Comm(void* arg)
{
  (void)arg;

  for (;;) {
    // chờ scheduler tick (notify từ ISR)
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

    Protocol::RxFrame f{};
    while (Protocol::tryRead(g_net, f)) {

      switch (f.group) {
        case Protocol::Group::SYSTEM:
          handleSystemCmd(f);
          // ACK cho tất cả SYSTEM CMD
          g_net.transmitUint8(Protocol::ACK_IDLE);
          printf("[ENC] total=%ld period_us=%lu rawP=%.2f rawA=%.2f out=%.2f\n",
          (long)Encoder::encoder_get_total(),
          (unsigned long)Encoder::encoder_get_period_us(),
          (double)Encoder::speed_get_hz_raw_period(),
          (double)Encoder::speed_get_hz_raw_accum(),
          (double)Encoder::speed_get_hz_out());


          break;

        case Protocol::Group::IDLE:
          handleIdleCmd(f);
          // ACK cho tất cả IDLE CMD
          g_net.transmitUint8(Protocol::ACK_IDLE);
          printf("[ENC] total=%ld period_us=%lu rawP=%.2f rawA=%.2f out=%.2f\n",
                (long)Encoder::encoder_get_total(),
                (unsigned long)Encoder::encoder_get_period_us(),
                (double)Encoder::speed_get_hz_raw_period(),
                (double)Encoder::speed_get_hz_raw_accum(),
                (double)Encoder::speed_get_hz_out());


          break;

        case Protocol::Group::OPERATION:
          handleOperationCmd(f);
          // OPERATION không bắt buộc ACK (tùy thiết kế)
          break;

        default:
          // UNKNOWN: bỏ qua
          break;
      }
    }
    // If state is OPERATION, send telemetry
    if (State::isOperation()) {

        uint8_t* line5;
        uint16_t ultra_u16  = 0;
        int16_t mpu6_i16[6] = {0,0,0,0,0,0};
        int8_t enc_i8       = 0;

        // Get speed
        float hz = Encoder::speed_get_hz_out();

        // tránh phụ thuộc lroundf (khỏi cần include <math.h>)
        int16_t speed_i16 = (int16_t)(hz * 100.0f + (hz >= 0 ? 0.5f : -0.5f)); // Hz*100
        enc_i8 = Encoder::encoder_snapshot_delta_and_reset_accum();

        Serial.printf("[ENC] total=%ld, period_us=%lu, hz=%.2f\n",
           (long)Encoder::encoder_get_total(),
           (unsigned long)Encoder::encoder_get_period_us(),
           (double)Encoder::speed_get_hz_out());

        // Update sensor data
        line5 = line_readSignals();
        ultra_u16 = ultra_getSignal(); 
        
        Telemetry::updateOpTelem22(line5, ultra_u16, mpu6_i16, enc_i8, speed_i16);
        Telemetry::sendOpTelem22(g_net);
    }

  }
}


// ======================= TASK: PID / CONTROL =======================

static void Task_PID(void* arg)
{
    (void)arg;
    const float Ts_s = (float)TS_CONTROLLER_MS / 1000.0f;

    for (;;) {
        ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

        if (!State::isOperation())                     continue;
        if (!gOpSp.enabled)                            continue;
        if (gOpSp.mode != OpDriveMode::SPEED_CLOSED_LOOP) continue;

        float v_meas_hz = fabsf(Encoder::speed_get_hz_out());
        float v_ref_hz  = gOpSp.speed_ref;
        float ref_abs   = fabsf(v_ref_hz);

        uint16_t duty_out = 0;
        Control::PID_update(gPid,
                            v_ref_hz,
                            v_meas_hz,
                            Ts_s,
                            duty_out,
                            &gPidDbg);

        // Deadband condition
        const uint16_t DUTY_MIN = MOTOR_DEADBAND_DUTY_DEFAULT;
        if (fabsf(gOpSp.speed_ref) > 1.0f && duty_out > 0 && duty_out < DUTY_MIN) duty_out = DUTY_MIN;
        if (duty_out > 2047) duty_out = 2047;

        if (v_ref_hz >= 0.0f) {
            MotorPWM11::driveForward(duty_out);
            Serial.printf("[PID] ref=%.2f meas=%.2f e=%.2f duty=%u\n",
            (double)v_ref_hz, (double)v_meas_hz, (double)(ref_abs - v_meas_hz),
            (unsigned)duty_out);
        } else {
            MotorPWM11::driveBackward(duty_out);
            Serial.printf("[PID] ref=%.2f meas=%.2f e=%.2f duty=%u\n",
            (double)v_ref_hz, (double)v_meas_hz, (double)(ref_abs - v_meas_hz),
            (unsigned)duty_out);
        }
    }
}
// constexpr float SPEED_PI_KP = 50.0f;   // duty/Hz, bạn phải tune
// constexpr float SPEED_PI_KI = 10.0f;   // duty/(Hz*s)

// static void Task_PID(void* arg)
// {
//     (void)arg;
//     const float Ts_s = (float)TS_CONTROLLER_MS / 1000.0f;

//     static float integ = 0.0f;  // tích phân lỗi

//     for (;;) {
//         ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

//         if (!State::isOperation())                     continue;
//         if (!gOpSp.enabled)                            continue;
//         if (gOpSp.mode != OpDriveMode::SPEED_CLOSED_LOOP) continue;

//         float v_meas_hz = Encoder::speed_get_hz_out();
//         float v_ref_hz  = gOpSp.speed_ref;

//         float err = v_ref_hz - v_meas_hz;

//         // DEBUG
//         printf("[PID] ref=%.2f Hz, meas=%.2f Hz, err=%.2f\n",
//                (double)v_ref_hz, (double)v_meas_hz, (double)err);

//         // PI đơn giản
//         integ += err * Ts_s;

//         float u = SPEED_PI_KP * err + SPEED_PI_KI * integ;

//         // Giới hạn duty trong [0, SPEED_MAX_INPUT]
//         if (u < 0.0f) u = 0.0f;
//         if (u > (float)MotorPWM11::SPEED_MAX_INPUT) {
//             u     = (float)MotorPWM11::SPEED_MAX_INPUT;
//             // optional: anti-windup đơn giản
//             // integ -= err * Ts_s; 
//         }

//         uint16_t duty_out = (uint16_t)(u + 0.5f);

//         // DEBUG
//         printf("[PID] duty=%.1f -> %u\n", (double)u, (unsigned)duty_out);

//         if (v_ref_hz >= 0.0f) {
//             MotorPWM11::driveForward(duty_out);
//         } else {
//             MotorPWM11::driveBackward(duty_out);
//         }
//     }
// }


// ======================= TASK: ULTRA =======================

static void Task_Ultra(void* arg)
{
  for (;;) {
    ulTaskNotifyTake(pdTRUE, portMAX_DELAY);

    // Ưu tiên thấp nhất, chỉ kích TRIG (10 us) nên không ảnh hưởng nhiều
    ultra_kick();
  }
}

// ======================= HANDLERS =======================

static void handleSystemCmd(const Protocol::RxFrame& f)
{
    using Protocol::Cmd;

    switch (f.cmd) {

    case Cmd::CMD_GLOBAL_OPERATION:
        // Vào OPERATION
        State::setMode(State::Mode::OPERATION);

        gOpSp.enabled   = false;
        gOpSp.mode      = OpDriveMode::PWM_OPEN_LOOP;
        gOpSp.pwm_cmd   = 0;
        gOpSp.speed_ref = 0.0f;
        gOpSp.steer_deg = SERVO_MID_DEG;

        MotorPWM11::stopMotor();
        break;

    case Cmd::CMD_GLOBAL_IDLE:
        // Về IDLE
        State::setMode(State::Mode::IDLE);

        gOpSp.enabled   = false;
        gOpSp.pwm_cmd   = 0;
        gOpSp.speed_ref = 0.0f;

        MotorPWM11::stopMotor();
        break;

    case Cmd::CMD_GLOBAL_PING_MODE:
        // Gửi 1 byte mode: 0 = IDLE, 1 = OPERATION
        g_net.transmitUint8(State::isOperation() ? 1 : 0);
        break;

    case Cmd::CMD_GLOBAL_EMRGENCY_STOP:
        // Dừng khẩn, về IDLE
        State::setMode(State::Mode::IDLE);

        gOpSp.enabled   = false;
        gOpSp.pwm_cmd   = 0;
        gOpSp.speed_ref = 0.0f;

        MotorPWM11::stopMotor();
        break;

    default:
        break;
    }
}


// Handle IDLE commands (sensors + debug actuators + set params)
static void handleIdleCmd(const Protocol::RxFrame& f)
{
  using namespace Protocol;
    Serial.printf("[IDLE] CMD=0x%02X\n", (uint8_t)f.cmd);


  switch (f.cmd) {
    // ---------- SENSOR ACTIONS ----------
    case Cmd::CMD_IDLE_SENSOR_LINE_READ: {
      uint8_t* sig = line_readSignals();  // 5 bytes raw
      g_net.transmitArrayUint8(sig, 5);
      break;
    }

    case Cmd::CMD_IDLE_SENSOR_ULTRA_KICK: {
      ultra_kick();
      break;
    }

    case Cmd::CMD_IDLE_SENSOR_ULTRA_READ: {
      uint16_t d = ultra_getSignal();
      uint8_t buf[2] = {
        (uint8_t)(d & 0xFF),
        (uint8_t)((d >> 8) & 0xFF)
      };
      g_net.transmitArrayUint8(buf, 2);
      break;
    }

    case Cmd::CMD_IDLE_ENCODER_ENABLE:
      Encoder::speed_filter_init();
      break;

    case Cmd::CMD_IDLE_ENCODER_DISABLE:
      // có thể set cờ riêng nếu muốn tắt hybrid_update
      break;

    // ---------- MOTOR ACTIONS (DEBUG / IDLE ONLY) ----------
    case Cmd::CMD_IDLE_ACTUATOR_MOTOR_ENABLE:
      // optional: set cờ "motorAllowedInIdle"
      break;

    case Cmd::CMD_IDLE_ACTUATOR_MOTOR_DISABLE:
      MotorPWM11::stopMotor();
      break;

    case Cmd::CMD_IDLE_ACTUATOR_MOTOR_PWM_FWD: {
      uint16_t v = f.u16; // 0..2047/2048, raw PWM debug
      v = Control::clampSpeedCmdToDuty11(v);
      MotorPWM11::driveForward(v);
      break;
    }

    case Cmd::CMD_IDLE_ACTUATOR_MOTOR_PWM_BWD: {
      uint16_t v = f.u16;
      v = Control::clampSpeedCmdToDuty11(v);
      MotorPWM11::driveBackward(v);
      break;
    }

    case Cmd::CMD_IDLE_ACTUATOR_MOTOR_SPD_FWD: {
      uint16_t v = f.u16; // có thể dùng cho test mapping speed
      v = Control::clampSpeedCmdToDuty11(v);
      MotorPWM11::driveForward(v);
      break;
    }

    case Cmd::CMD_IDLE_ACTUATOR_MOTOR_SPD_BWD: {
      uint16_t v = f.u16;
      v = Control::clampSpeedCmdToDuty11(v);
      MotorPWM11::driveBackward(v);
      break;
    }

    case Cmd::CMD_IDLE_ACTUATOR_MOTOR_STOP:
      MotorPWM11::stopMotor();
      break;

    // ---------- SERVO ACTIONS ----------
    case Cmd::CMD_IDLE_ACTUATOR_SERVO_ENABLE:
      // optional: set cờ enable servo
      break;

    case Cmd::CMD_IDLE_ACTUATOR_SERVO_DISABLE:
      Control::controlActuators(0, SERVO_MID_DEG);
      break;

    case Cmd::CMD_IDLE_ACTUATOR_SERVO_WRITE: {
      uint16_t ang = f.u16;
      if (ang < SERVO_MIN_DEG) ang = SERVO_MIN_DEG;
      if (ang > SERVO_MAX_DEG) ang = SERVO_MAX_DEG;
      Control::controlActuators(0, ang);
      break;
    }

    case Cmd::CMD_IDLE_ACTUATOR_SERVO_READ:
      // TODO: nếu cần đọc lại góc servo
      break;

    case Cmd::CMD_IDLE_ACTUATOR_SERVO_WRITE_CENTER:
      Control::controlActuators(0, SERVO_MID_DEG);
      break;

    // ---------- SET PARAMS: 30 BYTES ----------

    case Cmd::CMD_IDLE_SET_LINE_PARAMS: {
      // Mapping (30 bytes):
      //  byte 0 : uint8 lineSample (số mẫu trung bình cho line sensor)
      //  byte 1..29 : reserved / future use
      memcpy(gLineParams, f.bytes30, 30);

      uint8_t lineSample = gLineParams[0];
      if (lineSample == 0) lineSample = LINE_SAMPLE_DEFAULT;
      // TODO: nếu có API như line_setSampleCount(lineSample) thì gọi ở đây

      break;
    }

    case Cmd::CMD_IDLE_SET_MPU_PARAMS: {
      // Mapping (30 bytes):
      //  byte  0..1 : int16 accelOffsetX
      //  byte  2..3 : int16 accelOffsetY
      //  byte  4..5 : int16 accelOffsetZ
      //  byte  6..7 : int16 gyroOffsetX
      //  byte  8..9 : int16 gyroOffsetY
      //  byte 10..11: int16 gyroOffsetZ
      //  byte 12..29: reserved (scale, filter params,...)
      memcpy(gMpuParams, f.bytes30, 30);

      int16_t ax_off = (int16_t)((gMpuParams[1] << 8) | gMpuParams[0]);
      int16_t ay_off = (int16_t)((gMpuParams[3] << 8) | gMpuParams[2]);
      int16_t az_off = (int16_t)((gMpuParams[5] << 8) | gMpuParams[4]);
      int16_t gx_off = (int16_t)((gMpuParams[7] << 8) | gMpuParams[6]);
      int16_t gy_off = (int16_t)((gMpuParams[9] << 8) | gMpuParams[8]);
      int16_t gz_off = (int16_t)((gMpuParams[11] << 8) | gMpuParams[10]);

      // TODO: áp offsets này vào driver MPU nếu có (mpu_setOffsets(...))
      (void)ax_off; (void)ay_off; (void)az_off;
      (void)gx_off; (void)gy_off; (void)gz_off;

      break;
    }

    case Cmd::CMD_IDLE_SET_ULTRA_PARAMS: {
      // Mapping (30 bytes):
      //  byte 0..1 : uint16 trigPeriodMs (chu kỳ kích TRIG)
      //  byte 2..29: reserved
      memcpy(gUltraParams, f.bytes30, 30);

      uint16_t trigMs = (uint16_t)(gUltraParams[0] | (gUltraParams[1] << 8));
      if (trigMs == 0) trigMs = ULTRA_TRIG_PERIOD_MS_DEFAULT;
      gUltraPeriodMs = trigMs;   // dùng trong scheduler 1 ms

      break;
    }

    case Cmd::CMD_IDLE_SET_MOTOR_PARAMS: {
      // Mapping (30 bytes):
      //  byte 0..1 : uint16 motorDeadbandDuty (0..2047), chỉ dùng trong PID
      //  byte 2..3 : uint16 encTwMin_us (min period, microsecond) [optional]
      //  byte 4..5 : uint16 encTwMax_us (max period, microsecond) [optional]
      //  byte 6..7 : uint16 encF_low_x10  (F_low_Hz * 10) [optional]
      //  byte 8..9 : uint16 encF_high_x10 (F_high_Hz *10) [optional]
      //  byte 10..29: reserved
      memcpy(gMotorParams, f.bytes30, 30);

      uint16_t deadband = (uint16_t)(gMotorParams[0] | (gMotorParams[1] << 8));
      if (deadband > 2047) deadband = 2047;
      gPid.deadband_duty = deadband;

      // Các field encoder (2..9) hiện mới lưu lại, chưa áp dụng:
      // uint16_t twMin_us   = (uint16_t)(gMotorParams[2] | (gMotorParams[3] << 8));
      // uint16_t twMax_us   = (uint16_t)(gMotorParams[4] | (gMotorParams[5] << 8));
      // uint16_t fLow_x10   = (uint16_t)(gMotorParams[6] | (gMotorParams[7] << 8));
      // uint16_t fHigh_x10  = (uint16_t)(gMotorParams[8] | (gMotorParams[9] << 8));
      // TODO: map sang Encoder::HybridConfig nếu cần

      break;
    }

    case Cmd::CMD_IDLE_SET_SERVO_PARAMS: {
      // Mapping (30 bytes):
      //  byte 0..1 : uint16 servoMinDeg
      //  byte 2..3 : uint16 servoMaxDeg
      //  byte 4..5 : uint16 servoMidDeg
      //  byte 6..29: reserved
      memcpy(gServoParams, f.bytes30, 30);

      uint16_t sMin = (uint16_t)(gServoParams[0] | (gServoParams[1] << 8));
      uint16_t sMax = (uint16_t)(gServoParams[2] | (gServoParams[3] << 8));
      uint16_t sMid = (uint16_t)(gServoParams[4] | (gServoParams[5] << 8));

      // Hiện tại controlActuators vẫn dùng SERVO_MIN/MAX/MID compile-time.
      // TODO: nếu muốn runtime, cần chuyển sang biến global dùng trong control.cpp.
      (void)sMin; (void)sMax; (void)sMid;

      break;
    }

    case Cmd::CMD_IDLE_SET_PID_PARAMS: {
      // Mapping (30 bytes):
      //  byte  0..3 : float Kp       (IEEE754, little-endian)
      //  byte  4..7 : float Ki
      //  byte  8..11: float Kd
      //  byte 12..15: float windup_limit (|I| ≤ windup_limit)
      //  byte 16..17: uint16 dutyMin
      //  byte 18..19: uint16 dutyMax
      //  byte 20..23: float dutySlew_per_s
      //  byte 24..25: uint16 deadbandDuty (override MOTOR_DEADBAND, optional)
      //  byte 26..29: reserved
      memcpy(gPidParams, f.bytes30, 30);

      float kp, ki, kd, windup, slew;
      uint16_t dutyMin, dutyMax, deadband;

      memcpy(&kp,      &gPidParams[0],  4);
      memcpy(&ki,      &gPidParams[4],  4);
      memcpy(&kd,      &gPidParams[8],  4);
      memcpy(&windup,  &gPidParams[12], 4);
      memcpy(&dutyMin, &gPidParams[16], 2);
      memcpy(&dutyMax, &gPidParams[18], 2);
      memcpy(&slew,    &gPidParams[20], 4);
      memcpy(&deadband,&gPidParams[24], 2);

      Control::PID_init(gPid, kp, ki, kd, windup);
      Control::PID_setOutputLimits(gPid, dutyMin, dutyMax);
      Control::PID_setDerivativeFilter(gPid, PID_TAU_D_DEFAULT);
      Control::PID_setDutySlew(gPid, slew);

      if (deadband <= 2047) {
        gPid.deadband_duty = deadband;
      }

      break;
    }

    default:
      break;
  }
}

static void handleOperationCmd(const Protocol::RxFrame& f)
{
    using Protocol::Cmd;

    switch (f.cmd) {

    // ---------- PWM OPEN LOOP (u16) ----------
    case Cmd::CMD_OP_PWM_FWD:
    case Cmd::CMD_OP_PWM_BWD:
    {
        uint16_t duty = f.u16;
        if (duty > MotorPWM11::SPEED_MAX_INPUT) {
            duty = MotorPWM11::SPEED_MAX_INPUT;
        }

        gOpSp.mode    = OpDriveMode::PWM_OPEN_LOOP;
        gOpSp.enabled = true;
        gOpSp.pwm_cmd = duty;

        if (f.cmd == Cmd::CMD_OP_PWM_FWD) {
            MotorPWM11::driveForward(duty);
        } else {
            MotorPWM11::driveBackward(duty);
        }
        break;
    }

    // ---------- SPEED CLOSED LOOP (float32 Hz) ----------
    case Cmd::CMD_OP_SPD_FWD:
    case Cmd::CMD_OP_SPD_BWD:
    {
        float v_hz = f.f32;          // float32 [Hz] từ MATLAB

        if (f.cmd == Cmd::CMD_OP_SPD_BWD) {
            v_hz = -fabsf(v_hz);
        } else {
            v_hz =  fabsf(v_hz);
        }

        gOpSp.mode      = OpDriveMode::SPEED_CLOSED_LOOP;
        gOpSp.enabled   = true;
        gOpSp.speed_ref = v_hz;

        printf("[OP] SPD cmd=0x%02X ref=%.2f Hz\n",
        static_cast<uint8_t>(f.cmd), (double)v_hz);

        break;
    }

    case Cmd::CMD_OP_BRAKE:
    {
        gOpSp.enabled   = false;
        gOpSp.pwm_cmd   = 0;
        gOpSp.speed_ref = 0.0f;
        MotorPWM11::stopMotor();
        break;
    }

    default:
        break;
    }
}
