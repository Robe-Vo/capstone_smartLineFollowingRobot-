#include "dispatch.hpp"

namespace Dispatch {

    // Function pointer
    static Handler g_handlers[256] = {nullptr};

    // Regist function to pointer
    static inline void reg(uint8_t cmd, Handler h) { g_handlers[cmd] = h; }

    // Run action
    bool run(const Protocol::RxFrame& f)
    {
        Handler h = g_handlers[(uint8_t)f.cmd];
        if (!h) return false;
            h(f);
        return true;
    }

} // namespace Dispatch
