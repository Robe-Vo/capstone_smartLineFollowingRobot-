#pragma once
#include <stdint.h>

//  ======================= BLUETOOTH =======================
constexpr const char* DEVICE_NAME = "Behind the scream122";

// ======================= TIMING (milliseconds) =======================
constexpr uint32_t TS_CONTROLLER_MS    = 10;   // Speed control loop
constexpr uint32_t TS_COMMUNICATION_MS = 50;   // RX / TX poll
constexpr uint32_t TS_KICK_ULTRA       = 60;   // Default ultrasonic trigger period
constexpr uint32_t TS_RESET_TMR        = 100;  // Tick wrap

// alias nếu chỗ khác dùng hậu tố _MS
constexpr uint32_t TS_KICK_ULTRA_MS = TS_KICK_ULTRA;

// ======================= DC MOTOR / ENCODER / SERVO =======================
constexpr uint32_t PWM_FREQ_HZ  = 20000;  // 20 kHz
constexpr uint8_t  PWM_CH_MOTOR = 0;

// Encoder disc: 11 pulses/rev/channel → x4
constexpr uint16_t ENC_RESOLUTION    = 11;
constexpr uint16_t ENC_EFFECTIVE_PPR = ENC_RESOLUTION * 4u;

// Servo limits (default)
constexpr uint16_t SERVO_MIN_DEG = 55;
constexpr uint16_t SERVO_MAX_DEG = 105;
constexpr uint16_t SERVO_MID_DEG = 75;

// ======================= SAFETY =======================
constexpr uint32_t OP_TIMEOUT_MS = 200;

// ======================= PID: SPEED LOOP (DEFAULTS) =======================
// Dùng khi chưa nhận setupPID
constexpr float PID_KP_DEFAULT = 1.0f;
constexpr float PID_KI_DEFAULT = 0.0f;
constexpr float PID_KD_DEFAULT = 0.0f;

// |integral| ≤ WINDUP
constexpr float PID_WINDUP_LIMIT_DEFAULT = 0.0f;

// Duty clamp 11-bit
constexpr uint16_t PID_DUTY_MIN_DEFAULT = 0;
constexpr uint16_t PID_DUTY_MAX_DEFAULT = 2047;

// D-term filter (s), 0 = off
constexpr float PID_TAU_D_DEFAULT = 0.0f;

// Slew limit (counts/s), 0 = off
constexpr float PID_DUTY_SLEW_PER_S_DEFAULT = 0.0f;

// Deadband duty cho PID (không áp dụng cho lệnh PWM debug)
constexpr uint16_t MOTOR_DEADBAND_DUTY_DEFAULT = 500;


/**
 * ======================= ENCODER (DEFAULTS) =======================
 * */ 

// 1) Period glitch reject (us). Ignore unrealistically small periods (interrupt jitter/glitch).
//    Start around 200~500 us depending on max speed.
#define ENC_MIN_PERIOD_US               300

// 2) Stop/zero-speed timeout (us). If no pulses for this time -> speed = 0.
//    Typical: 100ms~300ms. Use longer if you run very slow.
#define TS_ENCODER_STOP_TIMEOUT_US      150000

// 3) Counts per revolution for accumulation method (A+B edges).
//    Example: disc=11 pulses per channel per rev.
//      - If you increment on CHANGE for both A and B (and you count every edge): approx 4x => 44.
//    You MUST set correctly for correct Hz scale.
#define ENC_COUNTS_PER_REV_ACC          (ENC_EFFECTIVE_PPR * 4)

// 4) Edges per revolution for period method on B only.
//    If you measure CHANGE on B only: 2 edges per B pulse => 22.
//    If you measure only RISING: 11.
#define ENC_EDGES_PER_REV_B             (ENC_EFFECTIVE_PPR * 2)

// 5) Alpha filter coefficient (0..1). Higher = faster response, less smoothing.
#define ENC_ALPHA                       0.25f

// 6) Jerk (slew-rate) limit for speed output [Hz/s].
#define ENC_JERK_LIMIT_HZ_PER_S         200.0f

// 7) Hybrid switching thresholds with hysteresis (Hz).
//    Switch to ACC at high speed, back to PERIOD at low speed.
#define ENC_SW_UP_HZ                    25.0f
#define ENC_SW_DN_HZ                    18.0f