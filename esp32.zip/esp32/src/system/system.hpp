#pragma once
#include <Arduino.h>

#include "state.hpp"
#include "handlers/system_handlers.hpp"
#include "handlers/idle_handlers.hpp"
#include "handlers/op_handlers.hpp"


