#include <Arduino.h>
#include "dispatch.hpp"

#include "protocol.hpp"
#include "../state.hpp"
#include "actuators.hpp"

/**
 *          ===== OPERATION HANDLERS =====
 * 
 *  Set flag and storage data whenever they are called
 */

static void forward_speed(const Protocol::RxFrame& f)
{
    op_params.direction = true;
    op_params.speed = f.speed_f;
}

static void forward_speed(const Protocol::RxFrame& f)
{
    op_params.direction = false;
    op_params.speed = f.speed_f;
}

static void forward_pwm(const Protocol::RxFrame& f)
{
    op_params.useController = false;
    op_params.direction = true;
    op_params.pwm = f.pwm_u16;
}

static void forward_speed(const Protocol::RxFrame& f)
{
    op_params.useController = false;
    op_params.direction = false;
    op_params.speed = f.pwm_u16;
}

// Stop - block action
static void robot_brake(const Protocol::RxFrame& f)
{
    Steer::disable();
    Drive::brake();
}

