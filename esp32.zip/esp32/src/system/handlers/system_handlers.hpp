#pragma once
#include <Arduino.h>
#include "dispatch.hpp"

#include "protocol.hpp"
#include "esp_system.h"
#include "../state.hpp"



static void to_idle(const Protocol::RxFrame& f)
{
    IDLE_init();
    robotMode = Mode::IDLE;
}

static void to_op(const Protocol::RxFrame& f)
{
    OPERATION_init();
    robotMode = Mode::OPERATION;
}

// Send back mode (After send ACK)
// 0: IDLE
// 1: OPERATION
static void ping()
{
    // get state
    uint8_t s = get_state();
    
    // Transmit back to host
}

// Stop - Reset esp32 (After send ACK)
static void emergency_stop()
{
    esp_restart();
}