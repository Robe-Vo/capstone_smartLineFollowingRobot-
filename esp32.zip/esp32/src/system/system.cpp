#include "system.hpp"

// IDLE program 
void idle_program()
{
    // Read cmd

    // Send ACK
}

// OPERATION program 
// Program action base on set flags
void op_program()
{
    // Read cmd

    // Read sensors signals

    // Control actuators

    // Send signals
}