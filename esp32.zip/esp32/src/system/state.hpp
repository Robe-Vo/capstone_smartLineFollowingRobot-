#pragma once
#include <Arduino.h>

#include "cfg.hpp"

/**
 * ======================================================================
 *                                STATE
 * ======================================================================
 * 
 *  This library control state and states' statuses of entirer system
 * */


enum class Mode: uint8_t {IDLE, OPERATION};
static Mode robotMode = Mode::IDLE;

/**
 *          ===== IDLE PARAMS ===== 
 * */
struct Idle_values
{
    // Motor flag
    bool motor_isWorking = false;
    // 0: Disable 
    // 1: (PID) Run forward - 2: (PID) Run backward 
    // 1: Run forward - 2: Run backward
    uint8_t motor_mode = 0;   

    // Servo flag
    bool servo_isWorking;
    int16_t servo_writeAngle = SERVO_MID_DEG;

    // Line sensors
    uint8_t* line_signals;

    // Ultra sensors
    uint16_t ultra_signal;

    // MPU sensor
    uint16_t* mpu_signal;
};

static Idle_values idle_params;

/**
 *          ===== OPERATION PARAMS ===== 
 * */
struct Op_RX_values
{
    // Run mode
    bool direction     = true;      // true: Forward | false: Backward
    bool useController = true;      // true: PID     | false: PWM
    bool isRunning     = true;     // Prevent controller to run while braking (block action)

    // Control params
    float speed = 0.0f;
    uint16_t pwm = 0;
};
static Op_RX_values op_params;

struct Op_TX_values
{
    // Line sensors
    uint8_t* line_signals;

    // Ultra sensors
    uint16_t ultra_signal;

    // MPU sensor - now is invalid
    uint16_t mpu_signal[5] = {0,0,0,0,0};
};
static Op_TX_values op_signals;


// Init IDLE
// Call when setup esp32 and switching mode
void IDLE_init();

// Init OPERATION
// Call when setup esp32 and switching mode
void OPERATION_init();

// Return robot's current state
// Return 1 if IDLE, 2 if OPERATION
bool get_state();